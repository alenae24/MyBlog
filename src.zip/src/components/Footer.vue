<template>
    <footer>
        <router-link class='link link-noactive' to="/">My<span>Blog</span></router-link>
    </footer>

  </template>
  
  <script>
  export default {
    name: 'Footer'
}
  </script>