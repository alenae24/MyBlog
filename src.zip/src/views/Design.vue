<template>
  <section class="join_us">
      <h1>В разработке</h1>
  </section>
    
  </template>
  
  <script>
  
  </script>